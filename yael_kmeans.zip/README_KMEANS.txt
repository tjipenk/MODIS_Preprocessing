Yeal_kmeans v 1.0
-----------------


Fast Kmeans clustering with Kmeans++ initialization. Based on the yael package

This toolbox can use BLAS/OpenMP API for faster computation on multi-cores processor.
It accepts dense inputs in single/double precision.

Installation
------------

Run "mexme_yael_kmeans.m" to compile mex-files.

Testing
-------

Run "test_yeal_kmeans.m" for demo

Online help by yael_kmeans in matlab prompt.


Reference  [1] Herv� J�gou, Matthijs Douze and Cordelia Schmid, Product quantization for nearest neighbor search,
---------      IEEE Transactions on Pattern Analysis and Machine Intelligence



Author : S�bastien PARIS : sebastien.paris@lsis.org
-------  Date : 11/04/2011

